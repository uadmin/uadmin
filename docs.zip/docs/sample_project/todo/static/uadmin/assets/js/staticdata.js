
    var arrayVariableHeader = [

    ];


    var arrayVariable = [

    ];



    var defaultOrg = "";
    defaultOrg += '<i class="fontdarkgray fa fa-sort-asc fa-stack-1x"></i>';
    defaultOrg += '<i class="fontdarkgray fa fa-sort-desc fa-stack-1x"></i>';


    var descOrg = "";
    descOrg += '<i class="fontgray fa fa-sort-asc fa-stack-1x"></i>';
    descOrg += '<i class="bluefont fa fa-sort-desc fa-stack-1x"></i>';

    var ascOrg = "";
    ascOrg += '<i class="bluefont fa fa-sort-asc fa-stack-1x"></i>';
    ascOrg += '<i class="fontgray fa fa-sort-desc fa-stack-1x"></i>';
